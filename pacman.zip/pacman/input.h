#ifndef INPUT_H
#define INPUT_H

#include "TYPES.H"

void process_keyboard_input(UCHAR8 input);
void set_input(Pacman *pacman, char input);

#endif