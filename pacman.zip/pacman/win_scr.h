#ifndef WIN_SCR_H
#define WIN_SCR_H
#include "types.h"
extern const ULONG32 win_splash[SPLASH_SIZE];
#endif