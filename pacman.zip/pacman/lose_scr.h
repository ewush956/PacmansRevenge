#ifndef LOSE_SCR_H
#define LOSE_SCR_H
#include "types.h"
extern const ULONG32 lose_splash[SPLASH_SIZE];
#endif