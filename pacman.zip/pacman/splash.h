#ifndef SPLASH_H
#define SPLASH_H
#include "types.h"
extern const ULONG32 splash[SPLASH_SIZE];

#endif